import { planetImageMap, characterImageMap } from './list.js';

document.addEventListener('DOMContentLoaded', () => {
	const button = document.querySelector('#obi');
	const results = document.querySelector('.results');
	const additionalInfo = document.querySelector('.additional-info');
	const searchQueryInput = document.querySelector('#searchQuery');
	const characterImage = document.querySelector('#characterImage');
	const planetImage = document.querySelector('#planetImage');

	button.addEventListener('click', getDataFromApi);

	function getCachedData(url) {
		const cachedData = localStorage.getItem(url);
		return cachedData ? JSON.parse(cachedData) : null;
	}

	function setCachedData(url, data) {
		localStorage.setItem(url, JSON.stringify(data));
	}

	async function fetchData(url) {
		let data = getCachedData(url);
		if (!data) {
			const response = await fetch(url);
			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}
			data = await response.json();
			setCachedData(url, data);
		}
		return data;
	}

	async function getDataFromApi() {
		const searchQuery = searchQueryInput.value.trim();
		const baseUrl = searchQuery ?
			`https://swapi.dev/api/people/?search=${searchQuery}` : //People search
			`https://swapi.dev/api/people/10/`;  // URL for Obi-Wan Kenobi

		try {
			const data = await fetchData(baseUrl);
			const character = searchQuery ? data.results[0] : data;

			if (character) {
				displayCharacterInfo(character);
				if (character.homeworld) {
					const homeworldData = await fetchData(character.homeworld);
					displayPlanetInfo(homeworldData);
				} else {
					additionalInfo.innerHTML = '';
					planetImage.style.display = 'none';
				}
			} else {
				searchForPlanet(searchQuery);
			}
		} catch (error) {
			console.error('Failed to fetch data:', error);
			results.innerHTML = `<p>Failed to fetch data. Please try again later.</p>`;
			additionalInfo.innerHTML = '';
			characterImage.style.display = 'none';
			planetImage.style.display = 'none';
		}
	}

	function displayCharacterInfo(character) {
		results.innerHTML = `
            <h2>Character Information</h2>
            <p>Name: ${character.name}</p>
            <p>Height: ${character.height}</p>
            <p>Mass: ${character.mass}</p>
            <p>Hair Color: ${character.hair_color}</p>
            <p>Skin Color: ${character.skin_color}</p>
            <p>Eye Color: ${character.eye_color}</p>
            <p>Birth Year: ${character.birth_year}</p>
            <p>Gender: ${character.gender}</p>
        `;

		const characterImageUrl = characterImageMap[character.name];
		if (characterImageUrl) {
			characterImage.src = characterImageUrl;
			characterImage.style.display = 'block';
			console.log(`Character image set: ${characterImageUrl}`);
		} else {
			characterImage.style.display = 'none';
			console.log('No character image found');
		}
	}

	function displayPlanetInfo(homeworldData) {
		additionalInfo.innerHTML = `
            <h2>Home Planet Information</h2>
            <p>Name: ${homeworldData.name}</p>
            <p>Rotation Period: ${homeworldData.rotation_period}</p>
            <p>Orbital Period: ${homeworldData.orbital_period}</p>
            <p>Diameter: ${homeworldData.diameter}</p>
            <p>Climate: ${homeworldData.climate}</p>
            <p>Gravity: ${homeworldData.gravity}</p>
            <p>Terrain: ${homeworldData.terrain}</p>
            <p>Surface Water: ${homeworldData.surface_water}</p>
            <p>Population: ${homeworldData.population}</p>
        `;

		const planetImageUrl = planetImageMap[homeworldData.name];
		if (planetImageUrl) {
			planetImage.src = planetImageUrl;
			planetImage.style.display = 'block';
			console.log(`Planet image set: ${planetImageUrl}`);
		} else {
			planetImage.style.display = 'none';
			console.log('No planet image found');
		}
	}

	async function searchForPlanet(searchQuery) {
		const planetUrl = `https://swapi.dev/api/planets/?search=${searchQuery}`; //Planet search
		try {
			const planetData = await fetchData(planetUrl);
			const planet = planetData.results[0];

			if (planet) {
				results.innerHTML = `
                    <h2>Planet Information</h2>
                    <p>Name: ${planet.name}</p>
                    <p>Rotation Period: ${planet.rotation_period}</p>
                    <p>Orbital Period: ${planet.orbital_period}</p>
                    <p>Diameter: ${planet.diameter}</p>
                    <p>Climate: ${planet.climate}</p>
                    <p>Gravity: ${planet.gravity}</p>
                    <p>Terrain: ${planet.terrain}</p>
                    <p>Surface Water: ${planet.surface_water}</p>
                    <p>Population: ${planet.population}</p>
                `;
				additionalInfo.innerHTML = '';

				const planetImageUrl = planetImageMap[planet.name];
				if (planetImageUrl) {
					planetImage.src = planetImageUrl;
					planetImage.style.display = 'block';
					characterImage.style.display = 'none';
					console.log(`Planet image set: ${planetImageUrl}`);
				} else {
					planetImage.style.display = 'none';
					console.log('No planet image found');
				}
			} else {
				results.innerHTML = `<p>No results found.</p>`;
				additionalInfo.innerHTML = '';
				planetImage.style.display = 'none';
				characterImage.style.display = 'none';
			}
		} catch (error) {
			console.error('Failed to fetch planet data:', error);
			results.innerHTML = `<p>Failed to fetch data. Please try again later.</p>`;
			additionalInfo.innerHTML = '';
			characterImage.style.display = 'none';
			planetImage.style.display = 'none';
		}
	}
});









